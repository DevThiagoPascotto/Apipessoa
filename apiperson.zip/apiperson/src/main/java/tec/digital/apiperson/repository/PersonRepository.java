package tec.digital.apiperson.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import tec.digital.apiperson.entity.Person;

public interface PersonRepository extends JpaRepository<Person, Long> {
}
