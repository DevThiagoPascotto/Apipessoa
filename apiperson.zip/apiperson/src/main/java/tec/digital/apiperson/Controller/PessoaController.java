package tec.digital.apiperson.Controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import tec.digital.apiperson.dto.MessageResponseDto;
import tec.digital.apiperson.entity.Person;
import tec.digital.apiperson.repository.PersonRepository;

@RestController
@RequestMapping("api/v/pessoa")

public class PessoaController {

    private PersonRepository personRepository;

    @Autowired
    public PessoaController(PersonRepository personRepository){
        this.personRepository = personRepository;
    }


    @PostMapping
    public MessageResponseDto createPerson(@RequestBody Person person) {
        Person savedPerson1 =  personRepository.save(person);
        return MessageResponseDto
                .builder()
                .message("Criado uma pessoa" + savedPerson1.getId())
                .build();
    }


    @GetMapping
    public String getbook(){
        return "Api test";
    }



    }

