package tec.digital.apiperson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApipersonApplicationTests {

	@Test
	void contextLoads() {
	}

}
